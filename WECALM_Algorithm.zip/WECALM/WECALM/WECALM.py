from collections import defaultdict
import string
from numpy import *
import time

from time import process_time
list_of_filenames=["data/human_PPI.txt","data/ppi_BioGRID.txt","data/SC_PPI.txt","DIP.txt"]
#current_file_name=""
def Read_File_Interactions(filename):
    #global current_file_name
    #current_file_name==filename.strip("data")+"_result"
    relations = defaultdict(list)
    label_id = {}
    id_label = {}
    total = 0
    print("the file interaction name is:",filename)
    read_point = open(filename,"r")
    for line in read_point.readlines():
        if filename.strip() not in list_of_filenames:
            line_interaction = str.split(line," ")
            #print(filename)
            first_name = line_interaction[1].strip()
            #print("first_name",first_name)
            last_name = line_interaction[2].strip()
            #print("last name",last_name)
        else:
            line_interaction = str.split(line,"\t")
            first_name = line_interaction[0].strip()
            #print("first_name",first_name)
            last_name = line_interaction[1].strip()
            
        if first_name not in label_id:
            label_id[first_name] = len(label_id)
            id_label[len(id_label)] = first_name
        if last_name not in label_id:
            label_id[last_name] = len(label_id)
            id_label[len(id_label)] = last_name
        if((not label_id[first_name] in relations[label_id[last_name]]) and first_name != last_name):
             total =total + 1
             relations[label_id[last_name]].append(label_id[first_name])
             relations[label_id[first_name]].append(label_id[last_name])
    print ("Total number of proteins:",len(label_id))
    print ("Total number of interactions:", total)
    return relations,label_id,id_label,total
#***************************************************************
def JD(id_protein,relation,Weight):
    for id in id_protein:
        neighbor = relation[id]
        for it in neighbor:
           if it > id:
              neighbor1 = relation[it]
              if len(neighbor) > 1 or len(neighbor1) > 1:
                  com = set (neighbor) & set (neighbor1)
                  union = set (neighbor) | set (neighbor1)
                  if len (com) < 1:
                      Weight[id, it] = 0.0
                  else:
                      Weight[id, it] = float (len (com)) / len (union)
                      Weight[it, id] = float (len (com)) / len (union)
              else:
                  Weight[id, it] = 0.0
    return Weight
#***************************************************************
def ECV2(id_protein,relation,W1):
    N = len(W1[0])
    weight = zeros((N,N))
    for id in id_protein:
        neighbor = relation[id]
        for it in neighbor:
          if id < it:
            weight_id_it = 0.0
            neighbor1 = relation[it]
            com = set(neighbor) & set(neighbor1)
            union = len(com)
            sum_common_weight = 0.0
            if len(com) > 0:
              for iw in com:
                sum_common_weight = sum_common_weight + W1[id,iw] * W1[it,iw]
              H_sencond = sum_common_weight
              H_sencond1 = (H_sencond + W1[id,it])/(union+1)
              weight[id,it] = H_sencond1
              weight[it,id] = H_sencond1
    relations = relation_interaction(id_protein,relation,weight)
    return weight,relations
#***************************************************************
def relation_interaction(id_protein,relation,Weight):
    #print "relation=", relation
    for id in id_protein:
        neighbor = relation[id]
        for it in neighbor:
            if Weight[id,it] == 0.0:
                neighbor.remove(it)
                relation[id] = neighbor
            else:
                #count = count + 1
                continue
    for it in id_protein:
        if len(relation[it]) <= 1:
            del relation[it]
    #print "relation1=",relation
    return relation
#***************************************************************
def dict_maxvalue(dicts):
    value = 0.0
    num = 0
    i = 1
    for ip in dicts:
        if i == 2:
            break
        else:
           value = dicts[ip]
           num = ip
           i = i +1

    for id in dicts:
        if dicts[id] >= value:
            value = dicts[id]
            num = id
        else:
            continue
    return num,value
#***************************************************************
def Core_minging_algorithm(id_protein,relation,ss):
    core_complex = dict()
    for id in id_protein:
       list_it = set()
       list_it.add(id)
       neighbor = relation[id]
       for it in neighbor:
         if id < it:
           score = Structure_similarity(id,it,relation)
           if score > ss:
               list_it.add(it)
       if len(list_it) >= 2:
           core_complex[id] = list(list_it)
    return core_complex
# **************************************************************
def Structure_similarity(id1,id2,relations):
    neighbor1 = relations[id1]
    neighbor2 = relations[id2]
    nei1 = set(neighbor1)
    nei1.add(id1)
    nei2 = set(neighbor2)
    nei2.add(id2)
    common_neibor = nei1 & nei2
    top = len(common_neibor)
    down = len(nei1) * len(nei2)
    structural_similarity = float(top) / (math.sqrt(down))
    return structural_similarity
#***************************************************************
def Clustering_coefficient_modularity(graph,relations,W):
    sum_inedge = 0.0
    graph = sorted(graph)
    graph_set = set(graph)
    count = 0
    for it in graph:
        neighbor = set(relations[it])
        #print "neighbor=",neighbor
        comm = neighbor & graph_set
        comm = list(comm)
        comm = sorted(comm)
        for iw in comm:
            if iw > it:
                sum_inedge = sum_inedge + W[it,iw]
                count = count + 1
    return sum_inedge,count
#***************************************************************
def mergeDuplicatedComplexes(pr,th_merge):
    a = set(pr.keys())
    print("a=",a) 
    b = set(pr.keys())
    print ("b=",b)
    for c1 in a:
        #print "c1=", c1
        for c2 in b:
            #print "c2=", c2
            if c1 == c2:
                continue
            if c1 not in pr:
                continue
            if c2 not in pr:
                continue
            complex1 = set(pr[c1])
            complex2 = set(pr[c2])
            l1 = len(complex1)
            l2 = len(complex2)
            inter = complex1 & complex2
            q = (1.0*len(inter)/l1)*(1.0*len(inter)/l2)
            if q >= th_merge:
                #print(str(q))
                for id in complex2-complex1:
                    pr[c1].append(id)
                del pr[c2]
    print ("set(pr.keys())=",set(pr.keys()))
    return pr
#***************************************************************
def Redundancy_filtering1(Core_dict,overlapscore,relations,W):
    visit = set()
    a = set(Core_dict.keys())
    b = set(Core_dict.keys())
    count = 0
    for id in a:
        if id not in visit:
          #density_id = Clustering_coefficient_modularity(Core_dict[id], relations, W)
          #print "Core_dict[id]=", id
          #avg_degree_id = density_id / len (Core_dict[id])
          #avg_degree_id = density_id
          for it in b:
            if it not in visit:
               if it > id:
                  set1 = set(Core_dict[id])
                  set2 = set(Core_dict[it])
                  score = Overlap_matchingscore(set1,set2)
                  #density_it = Clustering_coefficient_modularity(Core_dict[id],relations,W)
                  #avg_degree_it = density_it / len(Core_dict[it])
                  #avg_degree_it = density_it
                  if score >= overlapscore:
                    """
                    if avg_degree_id < avg_degree_it:
                      visit.add(it)
                      set1 = set2
                    else:
                      visit.add(it)
                      set1 = set1
                  """
                    visit.add(it)
                    Core_dict[id] = list(set1)
                    #Core_dict[id] = list(set1 | set2)
                    del Core_dict[it]
    #print "count=", count
    return Core_dict
#***************************************************************
def merge_complex(predicted_complexes,score):
    complexes1 = predicted_complexes
    complexes2 = predicted_complexes
    complexest = predicted_complexes
    complexest1 = defaultdict(list)
    markid = []
    k = 1
    for index1 in complexes1:
      if index1 not in markid:
        protein_sets = set(complexes1[index1])
        for index2 in complexes2:
            judge_overlapset = set(complexes2[index2])
            if index1 == index2:
                continue
            else:
              if index2 not in markid:
                MatchScore = Overlap_matchingscore(protein_sets,judge_overlapset)
                if MatchScore >= score:
                    for indexk in judge_overlapset:
                        if indexk not in complexest[index1]:
                           complexest[index1].append(indexk)
                    markid.append(index2)
                else:
                    continue
              else:
                  continue
      else:
          continue
      complexest1[k] = complexest[index1]
      k = k + 1
    return complexest1
#***************************************************************
def Overlap_matchingscore(Cluster_A,Cluster_B):
    # print "Cluster_A=",Cluster_A
    # print "Cluster_B=",Cluster_B
    overlap_set = Cluster_A & Cluster_B
    # print "overlap_set =",overlap_set
    overlap_num = float(len(overlap_set))
    union_set = Cluster_A | Cluster_B
    union_set_num = float(len(union_set))
    #Cluster_A_size = float(len (Cluster_A))
    # print "Cluster_A_size=",Cluster_A_size
    #Cluster_B_size = float(len (Cluster_B))
    # print "Cluster_B_size=",Cluster_B_size
    # O_A_B = overlap_num / (Cluster_A_size * Cluster_B_size)
    #O_A_B = (overlap_num * overlap_num) / (Cluster_A_size * Cluster_B_size)
    O_A_B = overlap_num / union_set_num
    # print "O_A_B=",O_A_B
    return O_A_B
# ***************************************************************
def Detecting_the_attachments(Core_dict,relation,W):
    complexes = dict()
    for id in Core_dict:
        #print "Core_dict[id]=",Core_dict[id]
        listwrq = Core_dict[id]
        listwrqs = Mining_attachments(listwrq,relation,W)
        #print "listwrqs =",listwrqs
        listwrqsort = list(set(listwrq + listwrqs))
        listwrqsort.sort()
        complexes[id] = listwrqsort
        #print "complexes[id] =",complexes[id]
    return complexes
# ***************************************************************
def graph_density(graph,relations,W):
    sum_inedge = 0.0
    graph = sorted(graph)
    graph_set = set(graph)
    for it in graph:
        neighbor = set(relations[it])
        #print "neighbor=",neighbor
        comm = neighbor & graph_set
        comm = list(comm)
        comm = sorted(comm)
        for iw in comm:
            if iw > it:
                sum_inedge = sum_inedge + W[it,iw]
    density = 2*float(sum_inedge)/ (len(graph)*(len(graph)-1))
    return density
#***************************************************************
def Mining_attachments(listwrq,relation,W):
    attachment_nodes = set()
    local_attachments = set()
    overlapping_attachments = set()
    for id in listwrq:
        neighbor = set(relation[id])
        attachment_nodes = attachment_nodes | neighbor
    attachment_nodes = attachment_nodes - set(listwrq)
    in_edges1,counts = Clustering_coefficient_modularity(listwrq,relation,W)
    averge_edges = 2*in_edges1 / len(listwrq)
    attachment_nodes_dict_in = {}
    attachment_nodes_dict_out = {}
    candidate_attachment_proteins = []
    overlapping_node = []
    peripheral_node = []
    for ih1 in attachment_nodes:
        count = 0
        neighbor_ne = relation[ih1]
        sum_ih1 = 0.0
        sum_ih1_out = 0.0
        for ib in neighbor_ne:
            if ib in listwrq:
                sum_ih1 = sum_ih1 + W[ih1,ib]
                count = count + 1
            else:
                sum_ih1_out = sum_ih1_out + W[ih1,ib]
        if count >= 2:
          candidate_attachment_proteins.append(ih1)
          attachment_nodes_dict_in[ih1] = sum_ih1
          attachment_nodes_dict_out[ih1] = sum_ih1_out
          if sum_ih1 <= sum_ih1_out:
              overlapping_node.append(ih1)
          else:
              peripheral_node.append(ih1)
    if len(overlapping_node) > 0:
      for io in overlapping_node:
          if attachment_nodes_dict_in[io] >= 0.5*averge_edges:
            overlapping_attachments.add(io)
    if len(peripheral_node) > 0:
        sum_in = 0.0
        for ij in peripheral_node:
            sum_in = sum_in + attachment_nodes_dict_in[ij]
        avg_peripheral_in = sum_in / len(peripheral_node)
        for ij in peripheral_node:
           if attachment_nodes_dict_in[ij] >= avg_peripheral_in:
             local_attachments.add(ij)
    attachment_nodes = local_attachments | overlapping_attachments
    #print "core proteins=",listwrq
    #print "local_attachments=",local_attachments
    #print "overlapping_attachments=",overlapping_attachments
    #print "===================================================="
    listwrqs = list(attachment_nodes)
    return listwrqs
# ***************************************************************
def CreateResultFile(seedt,id_protein,f ):#="Predict_result.txt"):
    #complexes = sort_complexes(seedt)
    complexes = seedt
    f = open(f,'w')
    k = 0
    for id in complexes:
        #print complexes[id]
        lists = complexes[id]
        if len(lists) >= 3:
            k = k + 1
            s = str(k)
            for name in lists:
                #print "name=",id_protein[name]
                s = s + " " + id_protein[name]
                #print(s)
                f.write(s+'\n')
            #print ( f, s)
    f.close ()
#***************************************************************
def delete_low_density(complex,relation,W):
    protein_complexes = dict()
    for id in complex:
        print ("complex=",complex[id])
        if len(complex[id]) <= 2:
            continue
        else:
            density, in_edges = Clustering_coefficient_modularity(set(complex[id]),relation,W)
            if density >= 0.3:
                protein_complexes[id] = complex[id]
            else:
                continue
            print (protein_complexes[id])
    return protein_complexes
#***************************************************************
def TO_ij_score(list1,list2):
    common_neighbor = set(list1) & set(list2)
    union_neighbor =  len(list1) * len(list2)
    common_neighbor_len = len(common_neighbor)
    #TO_ij = float(common_neighbor_len) / min(len(list1),len(list2))
    #TO_ij = float(2*common_neighbor_len + 1.0) / (len(list1) + len(list2))
    TO_ij = float(common_neighbor_len)**2 / (len(union_neighbor))
    return TO_ij
#***************************************************************
def calculate_Topology_score_weight(network,N):
    #print "network=",network
    #subnetwork_weight1 = defaultdict(list)
    subnetwork_relations = network
    #N = len(subnetwork_relations)
    #print "subnetwork_relations=",subnetwork_relations
    #print "N=",N
    Topology_weight = zeros((N,N))
    Id_key = subnetwork_relations.keys()
    for id in Id_key:
        neighbors = subnetwork_relations[id]
        for it in neighbors:
            sum_weight = 0.0
            neighbors1 = subnetwork_relations[it]
            score1_TO = TO_ij_score(neighbors,neighbors1)
            common_neighbor = set(neighbors) & set(neighbors1)
            for wrq in common_neighbor:
                neighbors2 = subnetwork_relations[wrq]
                sum_weight = TO_ij_score(neighbors,neighbors2) + TO_ij_score(neighbors1,neighbors2)
            Topology_weight[id,it] = (sum_weight + score1_TO)/(1*float(len(common_neighbor))+1)
            Topology_weight[it,id] = (sum_weight + score1_TO)/(1*float(len(common_neighbor))+1)
    return Topology_weight
#***************************************************************
def main(options):
    print (options)
    time_start = time.process_time()
    relations,protein_id,id_protein,total = Read_File_Interactions(options.fileinteractions)
    N = len(protein_id)
    Weight = zeros((N,N))
    #time_seed = time.process_time()
    #print "time_seed =", time_seed - time_start
    W1 = JD(id_protein,relations,Weight)
    #time_seed1 = time.process_time()
    #print "time_seed1 =", time_seed1 - time_seed
    Ws,relations = ECV2(id_protein,relations,W1)
    #time_seed2 = time.process_time()
    #print "time_seed2 =", time_seed2 - time_seed1
    #ss = 0.4
    complex = Core_minging_algorithm(id_protein,relations,float(options.structuralsimilarity))
    time_seed3 = time.process_time()
    #print "time_seed3 =", time_seed3 - time_seed2
    complexes = complex
    #print "***************************************************************"
    complexes = Detecting_the_attachments(complexes,relations,Ws)
    time_seed4 = time.process_time()
    print ("time_seed4 =", time_seed4 - time_seed3)
    complexes = Redundancy_filtering1(complexes,1.0,relations,Ws)
    #CreateResultFile(complexes,id_protein,"EWCA_results.txt")
    #CreateResultFile(complexes,id_protein, f="CP_BioGRID0.4Predict_result.txt")
    #CreateResultFile(complexes,id_protein, f="CP_STRING_Yeast0.4Predict_result.txt")#STRING_Yeast
    if options.fileinteractions in list_of_filenames:
      CreateResultFile(complexes,id_protein, f="results_{}".format(options.fileinteractions.strip('data/')))
    else:
      CreateResultFile(complexes,id_protein, f="results_{}".format(options.fileinteractions.replace('/','_')))
    print(options.fileinteractions.strip('data/'))#STRING_Yeast.txt
    #CreateResultFile(complexes, id_protein, f="CP_Yeast0.4Predict_result.txt")
    time_end = time.process_time()
    #print 'time_seed5', time_end - time_seed4, 's'
    print ('time cost',time_end-time_start,'s')
#main(options)