
WECLAM  is written in google colab and Python2 .

Programs/packages you must have:
Python2 (available at http://python.org/)

=============
From the commandline write the following commands:
$ python script_main.py -f [fileinteractions] -s [structuralsimilarity]";

-f = the files contains the protein interactions.
-os = overlapping structural similarity (defalt 0.4).
-ms = modularitity structural similarity (defalt 0.4).
-ss = core structural similarity (defalt 0.4).
For example, it runs as follows:
python script_main.py -f DIP.txt -s 0.4